# Assignment 4 , Spam Email Filtering

Python 3.8.2 version is used

Run main.py to see the results. Dataset should be in the same folder as .py files
```sh
python3 main.py 
```

Program will print the wanted scores. 
Randomization test is slow, you should wait 30 seconds